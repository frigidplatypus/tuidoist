#!/usr/bin/env python3
"""Entry point script for the Todoist TUI."""

from ptaskwarrior_tui.app import main

if __name__ == "__main__":
    main()
