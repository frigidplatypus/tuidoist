"""Custom widgets for the Todoist TUI."""

# This module can be extended with custom widgets if needed in the future
# For now, the app uses standard Textual widgets
