"""Ptaskwarrior TUI - A Textual-based TUI for Todoist tasks."""

from .app import TodoistTUI

__version__ = "0.1.0"
__all__ = ["TodoistTUI"]
